# Battery Shortage Prediction – MLOps Lab

## 1. Problem
Predict whether an electric scooter battery-swapping station will run short between 5 PM and 7 PM.

## 2. Setup
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## 3. Run the workflow (in this order)
```bash
python src/generate_data.py
python src/features.py
python src/train.py
```
The generator creates 250 records in each version:
- `data/evening_station_v1.csv`: normal operating period.
- `data/evening_station_v2.csv`: college festival period with increased demand.

The feature pipeline combines both versions and stores reusable engineered features in `feature_store/engineered_features.csv`.

## 4. Start the API
```bash
uvicorn src.api:app --reload
```
Open `http://127.0.0.1:8000/docs` for Swagger UI. POST to `/predict`.

Example JSON:
```json
{
  "charged_batteries_5pm": 15,
  "batteries_finishing_charge_by_7pm": 5,
  "advance_bookings": 24,
  "historical_walkin_demand": 18,
  "rainfall_forecast": "none",
  "is_weekend": 0,
  "nearby_event": 1,
  "festival_period": 1
}
```

## 5. Tests
```bash
pytest -q
```
The tests check feature calculations, API health, and rejection of negative battery counts. GitHub Actions runs the same checks on pushes and pull requests.

## 6. MLflow
Training logs model metrics and registers the selected model as `BatteryShortageClassifier`. To inspect runs:
```bash
mlflow ui --backend-store-uri sqlite:///mlflow.db
```
Then open `http://127.0.0.1:5000`.

## 7. Important notes
- The data is synthetic and intended for a lab demonstration, not real operational decisions.
- The split is stratified and uses a fixed random seed for repeatability.
- Model selection prioritizes shortage recall, then F1 and precision.
- The saved joblib pipeline includes preprocessing and classifier, so API inputs use the original raw feature columns.
