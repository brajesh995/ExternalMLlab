from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FEATURES = ROOT / "feature_store"
FEATURES.mkdir(exist_ok=True)

NUMERIC = [
    "charged_batteries_5pm", "batteries_finishing_charge_by_7pm",
    "advance_bookings", "historical_walkin_demand", "is_weekend",
    "nearby_event", "festival_period", "expected_battery_supply",
    "booking_pressure_ratio",
]
CATEGORICAL = ["rainfall_forecast"]
TARGET = "battery_shortage"

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["expected_battery_supply"] = (
        df["charged_batteries_5pm"] + df["batteries_finishing_charge_by_7pm"]
    )
    # A small denominator floor avoids division by zero.
    df["booking_pressure_ratio"] = (
        df["advance_bookings"] / df["expected_battery_supply"].clip(lower=1)
    )
    return df

if __name__ == "__main__":
    frames = []
    for version in (1, 2):
        path = DATA / f"evening_station_v{version}.csv"
        if not path.exists():
            raise FileNotFoundError(f"Run python src/generate_data.py first: {path}")
        frames.append(engineer_features(pd.read_csv(path)))
    combined = pd.concat(frames, ignore_index=True)
    out = FEATURES / "engineered_features.csv"
    combined.to_csv(out, index=False)
    print(f"Feature store saved: {out}")
    print(f"Rows: {len(combined)} | Columns: {len(combined.columns)}")
