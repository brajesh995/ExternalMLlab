from pathlib import Path
import json
import joblib
import mlflow
import mlflow.sklearn
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
FEATURE_FILE = ROOT / "feature_store" / "engineered_features.csv"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

NUMERIC = [
    "charged_batteries_5pm", "batteries_finishing_charge_by_7pm",
    "advance_bookings", "historical_walkin_demand", "is_weekend",
    "nearby_event", "festival_period", "expected_battery_supply",
    "booking_pressure_ratio",
]
CATEGORICAL = ["rainfall_forecast"]
TARGET = "battery_shortage"

def build_pipeline(classifier):
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])
    prep = ColumnTransformer([
        ("numeric", numeric_pipe, NUMERIC),
        ("categorical", categorical_pipe, CATEGORICAL),
    ])
    return Pipeline([("preprocessing", prep), ("classifier", classifier)])

def main():
    if not FEATURE_FILE.exists():
        raise FileNotFoundError("Run data generation and feature engineering first.")
    df = pd.read_csv(FEATURE_FILE)
    X, y = df[NUMERIC + CATEGORICAL], df[TARGET]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    candidates = {
        "LogisticRegression": LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=42
        ),
        "GradientBoosting": GradientBoostingClassifier(
            n_estimators=120, learning_rate=0.06, max_depth=2, random_state=42
        ),
    }
    results = []
    mlflow.set_tracking_uri((ROOT / "mlruns").as_uri())
    mlflow.set_experiment("battery-shortage-evening")

    for name, classifier in candidates.items():
        pipeline = build_pipeline(classifier)
        pipeline.fit(X_train, y_train)
        pred = pipeline.predict(X_test)
        metrics = {
            "accuracy": accuracy_score(y_test, pred),
            "precision": precision_score(y_test, pred, zero_division=0),
            "recall": recall_score(y_test, pred, zero_division=0),
            "f1": f1_score(y_test, pred, zero_division=0),
        }
        results.append((name, pipeline, metrics))
        with mlflow.start_run(run_name=name):
            mlflow.log_param("model", name)
            mlflow.log_metrics(metrics)
            mlflow.sklearn.log_model(pipeline, artifact_path="model")
        print(name, {k: round(v, 3) for k, v in metrics.items()})
        print("Confusion matrix [[TN, FP], [FN, TP]]:")
        print(confusion_matrix(y_test, pred))

    # Recall is prioritized because missing a real shortage is costly;
    # F1 breaks ties, then precision.
    best_name, best_model, best_metrics = max(
        results, key=lambda item: (item[2]["recall"], item[2]["f1"], item[2]["precision"])
    )
    joblib.dump(best_model, MODEL_DIR / "battery_shortage_model.joblib")
    (MODEL_DIR / "model_info.json").write_text(json.dumps({
        "model_name": best_name, "metrics": best_metrics,
        "selection_rule": "Highest shortage recall, then F1, then precision"
    }, indent=2))

    # Register the selected pipeline in the local MLflow Model Registry.
    # Requires a local SQLite-backed tracking server for registry support.
    mlflow.set_tracking_uri("sqlite:///" + str(ROOT / "mlflow.db"))
    mlflow.set_experiment("battery-shortage-registry")
    with mlflow.start_run(run_name=f"best-{best_name}") as run:
        mlflow.log_params({"selected_model": best_name, "selection_metric": "recall"})
        mlflow.log_metrics(best_metrics)
        mlflow.sklearn.log_model(
            best_model, artifact_path="model",
            registered_model_name="BatteryShortageClassifier"
        )
    print(f"Selected model: {best_name}")
    print("Registered as: BatteryShortageClassifier")
    print("Saved serving model to models/battery_shortage_model.joblib")

if __name__ == "__main__":
    main()
