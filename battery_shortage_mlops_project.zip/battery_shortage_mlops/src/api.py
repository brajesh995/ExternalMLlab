from pathlib import Path
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, model_validator

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "battery_shortage_model.joblib"
app = FastAPI(title="Battery Shortage Prediction API", version="1.0")

class StationConditions(BaseModel):
    charged_batteries_5pm: int = Field(ge=0)
    batteries_finishing_charge_by_7pm: int = Field(ge=0)
    advance_bookings: int = Field(ge=0)
    historical_walkin_demand: int = Field(ge=0)
    rainfall_forecast: str
    is_weekend: int = Field(ge=0, le=1)
    nearby_event: int = Field(ge=0, le=1)
    festival_period: int = Field(default=0, ge=0, le=1)

    @model_validator(mode="after")
    def check_rain(self):
        if self.rainfall_forecast not in {"none", "light", "heavy"}:
            raise ValueError("rainfall_forecast must be none, light, or heavy")
        return self

def make_features(data: StationConditions) -> pd.DataFrame:
    row = data.model_dump()
    row["expected_battery_supply"] = (
        row["charged_batteries_5pm"] + row["batteries_finishing_charge_by_7pm"]
    )
    row["booking_pressure_ratio"] = (
        row["advance_bookings"] / max(row["expected_battery_supply"], 1)
    )
    return pd.DataFrame([row])

@app.get("/")
def home():
    return {"message": "Battery Shortage Prediction API is running"}

@app.post("/predict")
def predict(conditions: StationConditions):
    if not MODEL_PATH.exists():
        raise HTTPException(status_code=503, detail="Model not found. Train the model first.")
    model = joblib.load(MODEL_PATH)
    features = make_features(conditions)
    prediction = int(model.predict(features)[0])
    probability = float(model.predict_proba(features)[0][1])
    return {
        "prediction": "Shortage Expected" if prediction == 1 else "Sufficient Batteries",
        "shortage_probability": round(probability, 4),
    }
