from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
RNG_SEED = 42

def make_version(version: int, n: int = 250) -> pd.DataFrame:
    """Create one reproducible evening-shift dataset version."""
    rng = np.random.default_rng(RNG_SEED + version)
    festival = version == 2

    charged = rng.integers(12, 46, n)
    charging = rng.integers(3, 19, n)
    bookings = rng.integers(4, 31, n)
    walkins = rng.integers(5, 27, n)
    rain = rng.choice(["none", "light", "heavy"], n, p=[0.55, 0.30, 0.15])
    weekend = rng.binomial(1, 0.28, n)
    nearby_event = rng.binomial(1, 0.20 if not festival else 0.48, n)

    # Simulated customer arrivals: festival version has an extra demand uplift.
    rain_effect = np.select([rain == "light", rain == "heavy"], [1.5, 3.0], default=0.0)
    festival_uplift = 7 if festival else 0
    arrivals_mean = (
        0.72 * bookings + 0.72 * walkins + 3.0
        + 2.0 * weekend + 3.5 * nearby_event + rain_effect + festival_uplift
    )
    arrivals = rng.poisson(np.maximum(arrivals_mean, 1))
    supply = charged + charging
    shortage = (arrivals > supply).astype(int)

    df = pd.DataFrame({
        "record_id": [f"v{version}_{i+1:03d}" for i in range(n)],
        "charged_batteries_5pm": charged,
        "batteries_finishing_charge_by_7pm": charging,
        "advance_bookings": bookings,
        "historical_walkin_demand": walkins,
        "rainfall_forecast": rain,
        "is_weekend": weekend,
        "nearby_event": nearby_event,
        "simulated_customer_arrivals": arrivals,
        "battery_shortage": shortage,
        "dataset_version": f"v{version}",
        "festival_period": int(festival),
    })
    return df

if __name__ == "__main__":
    for version in (1, 2):
        frame = make_version(version)
        path = DATA / f"evening_station_v{version}.csv"
        frame.to_csv(path, index=False)
        print(f"Saved {len(frame)} records -> {path}")
        print("Shortage rate:", round(frame["battery_shortage"].mean(), 3))
