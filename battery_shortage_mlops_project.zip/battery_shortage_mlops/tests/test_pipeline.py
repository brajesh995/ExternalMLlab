import sys
from pathlib import Path
import pandas as pd
import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from features import engineer_features
from api import app

client = TestClient(app)

def test_feature_engineering():
    sample = pd.DataFrame([{
        "charged_batteries_5pm": 10,
        "batteries_finishing_charge_by_7pm": 5,
        "advance_bookings": 6,
    }])
    result = engineer_features(sample)
    assert result.loc[0, "expected_battery_supply"] == 15
    assert result.loc[0, "booking_pressure_ratio"] == pytest.approx(0.4)

def test_negative_battery_count_rejected():
    response = client.post("/predict", json={
        "charged_batteries_5pm": -1,
        "batteries_finishing_charge_by_7pm": 5,
        "advance_bookings": 6,
        "historical_walkin_demand": 8,
        "rainfall_forecast": "none",
        "is_weekend": 0,
        "nearby_event": 0,
        "festival_period": 0
    })
    assert response.status_code == 422

def test_api_home():
    assert client.get("/").status_code == 200
